 <?php
                        
                     			if(isset($_POST['submit']))
									{
										$custid=$_POST['cid'];
										$name=$_POST['cname'];
										$father=$_POST['fname'];
										$mobile=$_POST['mobile'];
										$gen=$_POST['gender'];
										$intname=$_POST['intname'];
										$acopen=$_POST['acopendate'];
										$address=$_POST['address'];
									
										$sql ="insert into customer_details (CUSTOMER_ID,NAME,FATHER_NAME,MOBILE_NO,GENDER,INTRODUCER_NAME,AC_OPEN_DATE,ADDRESS) values ($custid',$name','$fname','$mobile','$gen','$intname','$acopen','$address')";	
										
										if($db->query($sql))
										{
											echo "User Registration Success !!";
										}
										else
										{
											echo "Data Insertion Failed";
										}
									}
									else
									{
										//echo "Please Enter All Fields";
									}
		
    							?>