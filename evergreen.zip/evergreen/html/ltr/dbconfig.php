<?php
		

	$db = mysqli_connect("localhost","root","","evergreen_fincrop");
		if($db->connect_errno)
		{
			echo $db->connect_error;
			die();
		}
		else
		{
		//echo "Connected To Database";
		}


?>



